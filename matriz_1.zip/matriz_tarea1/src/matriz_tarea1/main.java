package matriz_tarea1;


public class main {
	public static void main(String[] args)
	{
		
	int aux[][]={{3,6,9,3},{5,7,1,10},{4,5,7,2},{9,34,10,23}};
	matriz_tarea mat= new matriz_tarea(aux);
	mat.ordenar_desc(aux);
	System.out.println("ORDENADO DESCENDENTE");
	mat.mostrar(aux);
	mat.ordenar_asc(aux);
	System.out.println("ORDENADO ASCENDENTE");
	mat.mostrar(aux);
	
	mat.mayor(aux);
	mat.menor(aux);
	
	mat.promedio(aux);
	mat=null;
	}
}
